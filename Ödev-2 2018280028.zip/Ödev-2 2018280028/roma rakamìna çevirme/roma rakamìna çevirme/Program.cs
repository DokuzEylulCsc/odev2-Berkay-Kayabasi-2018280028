﻿using System;

namespace deneme
{
    class Program
    {
        // Kaynakça https://www.yazilimbilisim.net/c-sharp/c-console-ile-girilen-sayiyi-roma-rakamina-cevirme/
        static void Main(string[] args)
        {
            int binler = 0, yuzler = 0, onlar = 0, birler = 0, girilen;

            string sonuc = "";
            Console.Write("Lütfen bir sayı giriniz : ");

            girilen = Convert.ToInt32(Console.ReadLine());


            if (girilen <= 0 || girilen >= 4000)
            {
                Console.WriteLine("Lütfen 0 ile 4000 sayısı arasında bir değer giriniz");
            }



            else if (girilen - (binler * 1000) == 0)
            {
                goto romaDegerleri;

            }


            else if (girilen > 1000)
            {
                binler = girilen / 1000;

                yuzler = (girilen - (binler * 1000)) / 100;

                onlar = (girilen - ((binler * 1000) + (yuzler * 100))) / 10;

                birler = girilen - ((binler * 1000) + (yuzler * 100) + (onlar * 10));

            }

            else if (girilen > 100)
            {
                yuzler = girilen / 100;

                onlar = (girilen - (yuzler * 100)) / 10;

                birler = girilen - ((yuzler * 100) + (onlar * 10));
            }

            else if (girilen > 10)
            {
                onlar = girilen / 10;

                birler = girilen - (onlar * 10);

            }

            else
            {
                birler = girilen;
            }



        romaDegerleri:

            if (binler > 0)
            {
                switch (binler)
                {
                    case 1:
                        sonuc = "M";
                        break;

                    case 2:
                        sonuc = "MM";
                        break;

                    case 3:
                        sonuc = "MMM";
                        break;


                }
            }

            if (yuzler > 0)
            {
                switch (yuzler)
                {
                    case 1:
                        sonuc = sonuc + "C";
                        break;

                    case 2:
                        sonuc = sonuc + "CC";
                        break;

                    case 3:
                        sonuc = sonuc + "CCC";
                        break;

                    case 4:
                        sonuc = sonuc + "CD";
                        break;

                    case 5:
                        sonuc = sonuc + "D";
                        break;

                    case 6:
                        sonuc = sonuc + "DC";
                        break;

                    case 7:
                        sonuc = sonuc + "DCC";
                        break;

                    case 8:
                        sonuc = sonuc + "DCC";
                        break;

                    case 9:
                        sonuc = sonuc + "CM";
                        break;
                }
            }
            if (onlar > 0)
            {
                switch (onlar)
                {
                    case 1:
                        sonuc = sonuc + "X";
                        break;

                    case 2:
                        sonuc = sonuc + "XX";
                        break;

                    case 3:
                        sonuc = sonuc + "XXX";
                        break;

                    case 4:
                        sonuc = sonuc + "XL";
                        break;

                    case 5:
                        sonuc = sonuc + "L";
                        break;

                    case 6:
                        sonuc = sonuc + "LX";
                        break;

                    case 7:
                        sonuc = sonuc + "LXX";
                        break;

                    case 8:
                        sonuc = sonuc + "LXXX";
                        break;

                    case 9:
                        sonuc = sonuc + "XC";
                        break;
                }
            }

            if (birler > 0)
            {
                switch (birler)
                {
                    case 1:
                        sonuc = sonuc + "I";
                        break;

                    case 2:
                        sonuc = sonuc + "II";
                        break;

                    case 3:
                        sonuc = sonuc + "III";
                        break;

                    case 4:
                        sonuc = sonuc + "IV";
                        break;

                    case 5:
                        sonuc = sonuc + "V";
                        break;

                    case 6:
                        sonuc = sonuc + "VI";
                        break;

                    case 7:
                        sonuc = sonuc + "VII";
                        break;

                    case 8:
                        sonuc = sonuc + "VIII";
                        break;

                    case 9:
                        sonuc = sonuc + "IX";
                        break;
                }
            }



            Console.WriteLine(sonuc.ToString());
            Console.ReadKey();
        }


    }
}